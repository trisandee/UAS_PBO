/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MobilCRUDGUI extends JFrame {
    private Connection connection;
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtMerk, txtTahun, txtHarga;

    public MobilCRUDGUI() {
        // Setup database connection
        connectToDatabase();

        // Frame settings
        setTitle("CRUD Data Mobil");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Table
        tableModel = new DefaultTableModel(new String[]{"ID", "Merk", "Tahun", "Harga"}, 0);
        table = new JTable(tableModel);
        loadData();
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(new JLabel("Merk:"));
        txtMerk = new JTextField();
        inputPanel.add(txtMerk);

        inputPanel.add(new JLabel("Tahun:"));
        txtTahun = new JTextField();
        inputPanel.add(txtTahun);

        inputPanel.add(new JLabel("Harga:"));
        txtHarga = new JTextField();
        inputPanel.add(txtHarga);

        add(inputPanel, BorderLayout.NORTH);

        // Button panel
        JPanel buttonPanel = new JPanel();
        JButton btnAdd = new JButton("Tambah");
        JButton btnUpdate = new JButton("Ubah");
        JButton btnDelete = new JButton("Hapus");
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        add(buttonPanel, BorderLayout.SOUTH);

        // Button actions
        btnAdd.addActionListener(e -> addMobil());
        btnUpdate.addActionListener(e -> updateMobil());
        btnDelete.addActionListener(e -> deleteMobil());

        // Table row selection
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtMerk.setText(tableModel.getValueAt(row, 1).toString());
                txtTahun.setText(tableModel.getValueAt(row, 2).toString());
                txtHarga.setText(tableModel.getValueAt(row, 3).toString());
            }
        });

        setVisible(true);
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/uas_pbo"; // Ganti nama_database dengan nama database Anda
        String user = "root"; // Ganti jika username berbeda
        String password = ""; // Ganti jika password berbeda
        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Koneksi berhasil!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Koneksi database gagal!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadData() {
        try {
            tableModel.setRowCount(0);
            String sql = "SELECT * FROM data_mobil";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("idmobil"),
                        rs.getString("merk"),
                        rs.getInt("tahun"),
                        rs.getDouble("harga")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addMobil() {
        try {
            String merk = txtMerk.getText();
            int tahun = Integer.parseInt(txtTahun.getText());
            double harga = Double.parseDouble(txtHarga.getText());

            String sql = "INSERT INTO data_mobil (merk, tahun, harga) VALUES (?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, merk);
            stmt.setInt(2, tahun);
            stmt.setDouble(3, harga);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data mobil berhasil ditambahkan!");
            loadData();
            clearFields();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal menambahkan data mobil!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateMobil() {
        try {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Pilih data mobil yang ingin diubah!");
                return;
            }

            int id = (int) tableModel.getValueAt(row, 0);
            String merk = txtMerk.getText();
            int tahun = Integer.parseInt(txtTahun.getText());
            double harga = Double.parseDouble(txtHarga.getText());

            String sql = "UPDATE data_mobil SET merk = ?, tahun = ?, harga = ? WHERE idmobil = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, merk);
            stmt.setInt(2, tahun);
            stmt.setDouble(3, harga);
            stmt.setInt(4, id);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data mobil berhasil diubah!");
            loadData();
            clearFields();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal mengubah data mobil!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteMobil() {
        try {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Pilih data mobil yang ingin dihapus!");
                return;
            }

            int id = (int) tableModel.getValueAt(row, 0);

            String sql = "DELETE FROM data_mobil WHERE idmobil = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, id);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data mobil berhasil dihapus!");
            loadData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal menghapus data mobil!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        txtMerk.setText("");
        txtTahun.setText("");
        txtHarga.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MobilCRUDGUI::new);
    }
}