/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class PenjualanCRUDGUI extends JFrame {
    private Connection connection;
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtIdPelanggan, txtIdMobil, txtJumlah, txtTotalHarga, txtTanggal;

    public PenjualanCRUDGUI() {
        // Setup database connection
        connectToDatabase();

        // Frame settings
        setTitle("CRUD Data Penjualan");
        setSize(800, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Table
        tableModel = new DefaultTableModel(new String[]{
            "ID Penjualan", "ID Pelanggan", "ID Mobil", "Jumlah", "Total Harga", "Tanggal Penjualan"
        }, 0);
        table = new JTable(tableModel);
        loadData();
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("ID Pelanggan:"));
        txtIdPelanggan = new JTextField();
        inputPanel.add(txtIdPelanggan);

        inputPanel.add(new JLabel("ID Mobil:"));
        txtIdMobil = new JTextField();
        inputPanel.add(txtIdMobil);

        inputPanel.add(new JLabel("Jumlah:"));
        txtJumlah = new JTextField();
        inputPanel.add(txtJumlah);

        inputPanel.add(new JLabel("Total Harga:"));
        txtTotalHarga = new JTextField();
        inputPanel.add(txtTotalHarga);

        inputPanel.add(new JLabel("Tanggal (YYYY-MM-DD):"));
        txtTanggal = new JTextField();
        inputPanel.add(txtTanggal);

        add(inputPanel, BorderLayout.NORTH);

        // Button panel
        JPanel buttonPanel = new JPanel();
        JButton btnAdd = new JButton("Tambah");
        JButton btnUpdate = new JButton("Ubah");
        JButton btnDelete = new JButton("Hapus");
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        add(buttonPanel, BorderLayout.SOUTH);

        // Button actions
        btnAdd.addActionListener(e -> addPenjualan());
        btnUpdate.addActionListener(e -> updatePenjualan());
        btnDelete.addActionListener(e -> deletePenjualan());

        // Table row selection
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtIdPelanggan.setText(tableModel.getValueAt(row, 1).toString());
                txtIdMobil.setText(tableModel.getValueAt(row, 2).toString());
                txtJumlah.setText(tableModel.getValueAt(row, 3).toString());
                txtTotalHarga.setText(tableModel.getValueAt(row, 4).toString());
                txtTanggal.setText(tableModel.getValueAt(row, 5).toString());
            }
        });

        setVisible(true);
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/uas_pbo"; // Ganti nama_database dengan nama database Anda
        String user = "root"; // Ganti jika username berbeda
        String password = ""; // Ganti jika password berbeda
        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Koneksi berhasil!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Koneksi database gagal!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadData() {
        try {
            tableModel.setRowCount(0);
            String sql = "SELECT * FROM data_penjualan";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("id_penjualan"),
                    rs.getInt("id_pelanggan"),
                    rs.getInt("id_mobil"),
                    rs.getInt("jumlah"),
                    rs.getDouble("total_harga"),
                    rs.getDate("tanggal_penjualan")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addPenjualan() {
        try {
            int idPelanggan = Integer.parseInt(txtIdPelanggan.getText());
            int idMobil = Integer.parseInt(txtIdMobil.getText());
            int jumlah = Integer.parseInt(txtJumlah.getText());
            double totalHarga = Double.parseDouble(txtTotalHarga.getText());
            String tanggal = txtTanggal.getText();

            String sql = "INSERT INTO data_penjualan (id_pelanggan, id_mobil, jumlah, total_harga, tanggal_penjualan) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, idPelanggan);
            stmt.setInt(2, idMobil);
            stmt.setInt(3, jumlah);
            stmt.setDouble(4, totalHarga);
            stmt.setDate(5, Date.valueOf(tanggal));

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data penjualan berhasil ditambahkan!");
            loadData();
            clearFields();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal menambahkan data penjualan!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updatePenjualan() {
        try {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Pilih data penjualan yang ingin diubah!");
                return;
            }

            int idPenjualan = (int) tableModel.getValueAt(row, 0);
            int idPelanggan = Integer.parseInt(txtIdPelanggan.getText());
            int idMobil = Integer.parseInt(txtIdMobil.getText());
            int jumlah = Integer.parseInt(txtJumlah.getText());
            double totalHarga = Double.parseDouble(txtTotalHarga.getText());
            String tanggal = txtTanggal.getText();

            String sql = "UPDATE data_penjualan SET id_pelanggan = ?, id_mobil = ?, jumlah = ?, total_harga = ?, tanggal_penjualan = ? WHERE id_penjualan = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, idPelanggan);
            stmt.setInt(2, idMobil);
            stmt.setInt(3, jumlah);
            stmt.setDouble(4, totalHarga);
            stmt.setDate(5, Date.valueOf(tanggal));
            stmt.setInt(6, idPenjualan);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data penjualan berhasil diubah!");
            loadData();
            clearFields();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal mengubah data penjualan!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deletePenjualan() {
        try {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Pilih data penjualan yang ingin dihapus!");
                return;
            }

            int idPenjualan = (int) tableModel.getValueAt(row, 0);

            String sql = "DELETE FROM data_penjualan WHERE id_penjualan = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, idPenjualan);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data penjualan berhasil dihapus!");
            loadData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal menghapus data penjualan!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        txtIdPelanggan.setText("");
        txtIdMobil.setText("");
        txtJumlah.setText("");
        txtTotalHarga.setText("");
        txtTanggal.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PenjualanCRUDGUI::new);
    }
}