/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class PelangganCRUDGUI extends JFrame {
    private Connection connection;
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField txtIdPelanggan, txtNamaPelanggan, txtNikPelanggan, txtNoTelepon, txtAlamat;

    public PelangganCRUDGUI() {
        // Setup database connection
        connectToDatabase();

        // Frame settings
        setTitle("CRUD Data Pelanggan");
        setSize(800, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Table
        tableModel = new DefaultTableModel(new String[]{
            "ID Pelanggan", "Nama Pelanggan", "NIK", "No Telepon", "Alamat"
        }, 0);
        table = new JTable(tableModel);
        loadData();
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("ID Pelanggan:"));
        txtIdPelanggan = new JTextField();
        txtIdPelanggan.setEditable(false); // ID Pelanggan tidak dapat diedit
        inputPanel.add(txtIdPelanggan);

        inputPanel.add(new JLabel("Nama Pelanggan:"));
        txtNamaPelanggan = new JTextField();
        inputPanel.add(txtNamaPelanggan);

        inputPanel.add(new JLabel("NIK Pelanggan:"));
        txtNikPelanggan = new JTextField();
        inputPanel.add(txtNikPelanggan);

        inputPanel.add(new JLabel("No Telepon:"));
        txtNoTelepon = new JTextField();
        inputPanel.add(txtNoTelepon);

        inputPanel.add(new JLabel("Alamat:"));
        txtAlamat = new JTextField();
        inputPanel.add(txtAlamat);

        add(inputPanel, BorderLayout.NORTH);

        // Button panel
        JPanel buttonPanel = new JPanel();
        JButton btnAdd = new JButton("Tambah");
        JButton btnUpdate = new JButton("Ubah");
        JButton btnDelete = new JButton("Hapus");
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        add(buttonPanel, BorderLayout.SOUTH);

        // Button actions
        btnAdd.addActionListener(e -> addPelanggan());
        btnUpdate.addActionListener(e -> updatePelanggan());
        btnDelete.addActionListener(e -> deletePelanggan());

        // Table row selection
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtIdPelanggan.setText(tableModel.getValueAt(row, 0).toString());
                txtNamaPelanggan.setText(tableModel.getValueAt(row, 1).toString());
                txtNikPelanggan.setText(tableModel.getValueAt(row, 2).toString());
                txtNoTelepon.setText(tableModel.getValueAt(row, 3).toString());
                txtAlamat.setText(tableModel.getValueAt(row, 4).toString());
            }
        });

        setVisible(true);
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/uas_pbo"; // Ganti nama_database dengan nama database Anda
        String user = "root"; // Ganti jika username berbeda
        String password = ""; // Ganti jika password berbeda
        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Koneksi berhasil!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Koneksi database gagal!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadData() {
        try {
            tableModel.setRowCount(0); // Clear the existing data in the table
            String sql = "SELECT * FROM data_pelanggan";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("id_pelanggan"),
                    rs.getString("nama_pelanggan"),
                    rs.getString("nik_pelanggan"),
                    rs.getString("no_telepon"),
                    rs.getString("alamat")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addPelanggan() {
        try {
            String nama = txtNamaPelanggan.getText();
            String nik = txtNikPelanggan.getText();
            String noTelepon = txtNoTelepon.getText();
            String alamat = txtAlamat.getText();

            String sql = "INSERT INTO data_pelanggan (nama_pelanggan, nik_pelanggan, no_telepon, alamat) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, nama);
            stmt.setString(2, nik);
            stmt.setString(3, noTelepon);
            stmt.setString(4, alamat);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data pelanggan berhasil ditambahkan!");
            loadData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal menambahkan data pelanggan!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updatePelanggan() {
        try {
            int idPelanggan = Integer.parseInt(txtIdPelanggan.getText());
            String nama = txtNamaPelanggan.getText();
            String nik = txtNikPelanggan.getText();
            String noTelepon = txtNoTelepon.getText();
            String alamat = txtAlamat.getText();

            String sql = "UPDATE data_pelanggan SET nama_pelanggan = ?, nik_pelanggan = ?, no_telepon = ?, alamat = ? WHERE id_pelanggan = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, nama);
            stmt.setString(2, nik);
            stmt.setString(3, noTelepon);
            stmt.setString(4, alamat);
            stmt.setInt(5, idPelanggan);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data pelanggan berhasil diubah!");
            loadData();
            clearFields();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal mengubah data pelanggan!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deletePelanggan() {
        try {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Pilih data pelanggan yang ingin dihapus!");
                return;
            }

            int idPelanggan = (int) tableModel.getValueAt(row, 0);

            String sql = "DELETE FROM data_pelanggan WHERE id_pelanggan = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, idPelanggan);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data pelanggan berhasil dihapus!");
            loadData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal menghapus data pelanggan!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        txtIdPelanggan.setText("");
        txtNamaPelanggan.setText("");
        txtNikPelanggan.setText("");
        txtNoTelepon.setText("");
        txtAlamat.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PelangganCRUDGUI::new);
    }
}
